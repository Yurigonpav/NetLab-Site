"""
utils/compat.py
Camada de compatibilidade entre Windows e Linux para o NetLab Educacional.

Centraliza detecção de SO, kwargs de subprocess, verificação de privilégios
e detecção do driver de captura de pacotes.
"""

from __future__ import annotations

import os
import platform
import subprocess


# ── Detecção de SO ──────────────────────────────────────────────────────────

def eh_windows() -> bool:
    """Retorna True se o sistema operacional é Windows."""
    return os.name == "nt"


def eh_linux() -> bool:
    """Retorna True se o sistema operacional é Linux."""
    return platform.system() == "Linux"


# ── Subprocess ──────────────────────────────────────────────────────────────

_CREATE_NO_WINDOW = 0x08000000

def subprocess_kwargs() -> dict:
    """
    Retorna kwargs extras para subprocess.run / subprocess.Popen.

    No Windows, inclui ``creationflags=CREATE_NO_WINDOW`` para evitar
    janelas de console. No Linux, retorna dicionário vazio.
    """
    if eh_windows():
        return {"creationflags": _CREATE_NO_WINDOW}
    return {}


# ── Privilégios ─────────────────────────────────────────────────────────────

def eh_admin() -> bool:
    """
    Verifica se o processo atual possui privilégios elevados.

    - Windows: ``ctypes.windll.shell32.IsUserAnAdmin()``
    - Linux: ``os.geteuid() == 0``
    """
    if eh_windows():
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except (AttributeError, OSError):
            return False
    # Linux / macOS
    return os.geteuid() == 0


# ── Driver de Captura ───────────────────────────────────────────────────────

def obter_versao_driver_captura() -> str:
    """
    Retorna a versão do driver de captura de pacotes.

    - Windows: lê a versão do Npcap no registro do Windows.
    - Linux: verifica a versão da libpcap instalada.

    Retorna ``"N/A"`` se não for possível detectar.
    """
    if eh_windows():
        return _versao_npcap()
    return _versao_libpcap()


def _versao_npcap() -> str:
    """Lê a versão do Npcap do registro do Windows."""
    try:
        import winreg
        for chave in (
            r"SOFTWARE\Npcap",
            r"SOFTWARE\WOW6432Node\Npcap",
        ):
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, chave) as k:
                    versao, _ = winreg.QueryValueEx(k, "")
                    if versao:
                        return str(versao)
            except FileNotFoundError:
                continue
    except ImportError:
        pass

    # Fallback: verifica pela DLL do Npcap
    dll_path = r"C:\Windows\System32\Npcap\wpcap.dll"
    if os.path.exists(dll_path):
        return "Instalado (versão desconhecida)"

    return "N/A"


def _versao_libpcap() -> str:
    """Detecta a versão da libpcap no Linux."""
    try:
        proc = subprocess.run(
            ["dpkg-query", "-W", "-f=${Version}", "libpcap-dev"],
            capture_output=True, text=True, timeout=5,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Fallback: tentar via ldconfig
    try:
        proc = subprocess.run(
            ["ldconfig", "-p"],
            capture_output=True, text=True, timeout=5,
        )
        if proc.returncode == 0:
            for linha in proc.stdout.splitlines():
                if "libpcap.so" in linha:
                    return "Instalada"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Último fallback: verificar se o arquivo .so existe
    import ctypes.util
    caminho = ctypes.util.find_library("pcap")
    if caminho:
        return "Instalada"

    return "N/A"
