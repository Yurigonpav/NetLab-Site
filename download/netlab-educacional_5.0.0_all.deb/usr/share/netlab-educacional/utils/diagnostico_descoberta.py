"""
Módulo para descoberta de rede e identificação de dispositivos.
Varredura ARP, ICMP, NBNS, mDNS, SSDP.
"""

import subprocess
import re
import json
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

from utils.compat import subprocess_kwargs, eh_windows

try:
    from scapy.all import Ether, ARP, conf, srp, IP, ICMP
    SCAPY_DISPONIVEL = True
except ImportError:
    SCAPY_DISPONIVEL = False


@dataclass
class DispositivoRede:
    """Dispositivo descoberto na rede."""
    ip: str
    mac: str = ""
    hostname: str = ""
    fabricante: str = ""
    portas_abertas: List[int] = field(default_factory=list)
    tipo_dispositivo: str = "Desconhecido"
    latencia_ms: float = 0.0
    ttl: int = 0
    online: bool = True
    
    def para_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return asdict(self)


class DiscoveriaRede:
    """Ferramentas para descoberta de dispositivos na rede."""

    @staticmethod
    def varredura_arp(rede_cidr: str, timeout: int = 2) -> List[DispositivoRede]:
        """
        Executa varredura ARP ativa em uma sub-rede.
        """
        dispositivos = []
        
        if not SCAPY_DISPONIVEL:
            return dispositivos
        
        try:
            # Criar pacote ARP Request
            arp = ARP(pdst=rede_cidr)
            ether = Ether(dst="ff:ff:ff:ff:ff:ff")
            pacote = ether / arp
            
            # Enviar e receber respostas
            resposta, _ = srp(pacote, timeout=timeout, verbose=False)
            
            for _, recebido in resposta:
                dispositivo = DispositivoRede(
                    ip=recebido.psrc,
                    mac=recebido.hwsrc,
                )
                dispositivos.append(dispositivo)
        
        except Exception as e:
            pass
        
        return dispositivos

    @staticmethod
    def obter_dispositivos_conectados() -> List[DispositivoRede]:
        """
        Obtém lista de dispositivos conectados usando ARP table do sistema de forma cross-platform.
        """
        dispositivos = []
        
        if eh_windows():
            try:
                cmd = (
                    "Get-NetNeighbor -AddressFamily IPv4 -State Reachable | "
                    "Select-Object IPAddress, LinkLayerAddress, State | "
                    "ConvertTo-Json"
                )
                proc = subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                    capture_output=True, text=True, timeout=10,
                    **subprocess_kwargs()
                )
                if proc.returncode == 0 and proc.stdout.strip():
                    dados = json.loads(proc.stdout)
                    if isinstance(dados, dict):
                        dados = [dados]
                    for item in dados:
                        if item:
                            dispositivos.append(DispositivoRede(
                                ip=item.get("IPAddress", ""),
                                mac=item.get("LinkLayerAddress", ""),
                            ))
            except Exception:
                pass
        else:
            # ── Linux: ip -j neigh ──
            try:
                proc = subprocess.run(
                    ["ip", "-j", "-4", "neigh", "show"],
                    capture_output=True, text=True, timeout=5,
                    **subprocess_kwargs()
                )
                if proc.returncode == 0 and proc.stdout.strip():
                    dados = json.loads(proc.stdout)
                    for item in dados:
                        ip = item.get("dst", "")
                        mac = item.get("lladdr", "")
                        if ip and mac and mac != "00:00:00:00:00:00":
                            dispositivos.append(DispositivoRede(
                                ip=ip,
                                mac=mac,
                            ))
            except Exception:
                # Fallback: /proc/net/arp
                try:
                    with open("/proc/net/arp", "r") as f:
                        for linha in f.readlines()[1:]:
                            partes = linha.split()
                            if len(partes) >= 4:
                                ip = partes[0]
                                mac = partes[3]
                                if ip and mac and mac != "00:00:00:00:00:00":
                                    dispositivos.append(DispositivoRede(ip=ip, mac=mac))
                except Exception:
                    pass
        
        return dispositivos

    @staticmethod
    def resolver_hostname(ip: str) -> str:
        """
        Tenta resolver hostname a partir de IP.
        """
        try:
            import socket
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname
        except:
            return ""

    @staticmethod
    def detectar_tipo_dispositivo(ip: str, portas_abertas: List[int]) -> str:
        """
        Tenta detectar o tipo de dispositivo baseado em portas abertas.
        """
        # Portas comuns por tipo de dispositivo
        if 443 in portas_abertas or 80 in portas_abertas:
            if 9100 in portas_abertas:
                return "Impressora com web"
            return "Servidor Web / PC"
        
        if 3306 in portas_abertas or 5432 in portas_abertas:
            return "Servidor de Banco de Dados"
        
        if 3389 in portas_abertas:
            return "Windows RDP"
        
        if 22 in portas_abertas:
            return "Linux/Unix SSH"
        
        if 9100 in portas_abertas or 515 in portas_abertas:
            return "Impressora de Rede"
        
        if 5000 in portas_abertas or 8080 in portas_abertas:
            return "Serviço Custom"
        
        return "Dispositivo Genérico"

    @staticmethod
    def descoberta_completa() -> List[DispositivoRede]:
        """
        Executa descoberta completa de rede.
        """
        dispositivos = DiscoveriaRede.obter_dispositivos_conectados()
        
        # Enriquecer dados
        for dispositivo in dispositivos:
            dispositivo.hostname = DiscoveriaRede.resolver_hostname(dispositivo.ip)
        
        return dispositivos
