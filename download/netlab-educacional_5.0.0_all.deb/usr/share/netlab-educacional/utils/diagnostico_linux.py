"""
utils/diagnostico_linux.py
Módulo para verificações específicas do sistema Linux.
Firewall (UFW/iptables/nftables), AppArmor/SELinux, Raw Sockets, VPN, adaptadores virtuais.
"""

from __future__ import annotations

import os
import subprocess
import re
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any

from utils.compat import subprocess_kwargs, eh_admin


@dataclass
class VerificacaoLinux:
    """Resultado de verificações do Linux (equivalente estrutural a VerificacaoWindows)."""
    firewall_ativado: bool = False
    defender_ativado: bool = False  # AppArmor / SELinux
    winsock_ok: bool = True         # Permissões de captura / Raw Sockets
    drivers_ndis_ok: bool = True    # Stack de rede Linux
    vpn_detectada: bool = False
    adapters_virtuais: int = 0
    nome_firewall: str = "Nenhum"
    nome_seguranca: str = "Nenhum"
    problemas: List[str] = field(default_factory=list)
    avisos: List[str] = field(default_factory=list)
    recomendacoes: List[str] = field(default_factory=list)

    def para_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return asdict(self)


class DiagnosticoLinux:
    """Verificações específicas do sistema Linux."""

    @staticmethod
    def verificar_firewall() -> tuple[bool, str]:
        """
        Verifica se UFW, iptables, nftables ou firewalld está ativo.
        Retorna (ativo: bool, nome: str).
        """
        # 1. UFW
        try:
            proc = subprocess.run(
                ["ufw", "status"],
                capture_output=True, text=True, timeout=3,
                **subprocess_kwargs()
            )
            if proc.returncode == 0 and "Status: active" in proc.stdout:
                return True, "UFW (Ativo)"
        except Exception:
            pass

        # 2. firewalld
        try:
            proc = subprocess.run(
                ["firewall-cmd", "--state"],
                capture_output=True, text=True, timeout=3,
                **subprocess_kwargs()
            )
            if proc.returncode == 0 and "running" in proc.stdout.lower():
                return True, "Firewalld (Ativo)"
        except Exception:
            pass

        # 3. nftables
        try:
            proc = subprocess.run(
                ["nft", "list", "ruleset"],
                capture_output=True, text=True, timeout=3,
                **subprocess_kwargs()
            )
            if proc.returncode == 0 and proc.stdout.strip():
                return True, "nftables (Regras ativas)"
        except Exception:
            pass

        # 4. iptables
        try:
            proc = subprocess.run(
                ["iptables", "-L", "-n"],
                capture_output=True, text=True, timeout=3,
                **subprocess_kwargs()
            )
            if proc.returncode == 0:
                linhas = [l for l in proc.stdout.splitlines() if l.strip() and not l.startswith("Chain") and not l.startswith("target")]
                if len(linhas) > 0:
                    return True, "iptables (Regras ativas)"
        except Exception:
            pass

        return False, "Nenhum firewall detectado / Inativo"

    @staticmethod
    def verificar_modulo_seguranca() -> tuple[bool, str]:
        """
        Verifica se AppArmor ou SELinux está ativo.
        Retorna (ativo: bool, nome: str).
        """
        # AppArmor
        if os.path.exists("/sys/kernel/security/apparmor/profiles"):
            try:
                proc = subprocess.run(
                    ["aa-status", "--enabled"],
                    capture_output=True, text=True, timeout=3,
                    **subprocess_kwargs()
                )
                if proc.returncode == 0:
                    return True, "AppArmor (Ativo)"
            except Exception:
                return True, "AppArmor (Habilitado no Kernel)"

        # SELinux
        if os.path.exists("/sys/fs/selinux/enforce"):
            try:
                with open("/sys/fs/selinux/enforce", "r") as f:
                    if f.read().strip() == "1":
                        return True, "SELinux (Enforcing)"
                    else:
                        return True, "SELinux (Permissive)"
            except Exception:
                pass

        return False, "Nenhum LSM ativo"

    @staticmethod
    def verificar_raw_sockets() -> bool:
        """
        Verifica se o processo tem permissão para abrir raw sockets.
        """
        if eh_admin():
            return True

        import socket
        try:
            s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(0x0800))
            s.close()
            return True
        except PermissionError:
            return False
        except Exception:
            return False

    @staticmethod
    def verificar_stack_rede() -> bool:
        """
        Verifica se a stack de rede do kernel Linux e loopback estão operacionais.
        """
        return os.path.exists("/proc/net/dev")

    @staticmethod
    def verificar_vpn() -> bool:
        """
        Detecta interfaces de VPN (tun, tap, wg, ppp).
        """
        try:
            if os.path.exists("/sys/class/net"):
                for iface in os.listdir("/sys/class/net"):
                    if iface.startswith(("tun", "tap", "wg", "ppp", "nordlynx", "tailscale", "proton")):
                        return True
        except Exception:
            pass
        return False

    @staticmethod
    def contar_adapters_virtuais() -> int:
        """
        Conta interfaces de rede virtuais (docker, br, veth, virbr, etc).
        """
        count = 0
        try:
            if os.path.exists("/sys/class/net"):
                for iface in os.listdir("/sys/class/net"):
                    if iface.startswith(("docker", "veth", "br-", "virbr", "vmnet", "vboxnet")):
                        count += 1
        except Exception:
            pass
        return count

    @staticmethod
    def diagnostico_linux_completo() -> VerificacaoLinux:
        """
        Executa todas as verificações do Linux e gera relatório com avisos e recomendações.
        """
        verificacao = VerificacaoLinux()

        # 1. Firewall
        verificacao.firewall_ativado, verificacao.nome_firewall = DiagnosticoLinux.verificar_firewall()

        # 2. Segurança (LSM)
        verificacao.defender_ativado, verificacao.nome_seguranca = DiagnosticoLinux.verificar_modulo_seguranca()

        # 3. Permissões de Raw Socket / Captura
        verificacao.winsock_ok = DiagnosticoLinux.verificar_raw_sockets()
        if not verificacao.winsock_ok:
            verificacao.problemas.append("Sem permissão para captura de pacotes (Raw Socket)")
            verificacao.recomendacoes.append("Execute o NetLab com 'sudo python3 main.py' ou conceda cap_net_raw: 'sudo setcap cap_net_raw,cap_net_admin=eip $(which python3)'")

        # 4. Stack de rede
        verificacao.drivers_ndis_ok = DiagnosticoLinux.verificar_stack_rede()
        if not verificacao.drivers_ndis_ok:
            verificacao.problemas.append("Stack de rede do Linux (/proc/net/dev) inacessível")

        # 5. VPN
        verificacao.vpn_detectada = DiagnosticoLinux.verificar_vpn()
        if verificacao.vpn_detectada:
            verificacao.avisos.append("VPN ativa detectada (pode alterar o tráfego capturado)")

        # 6. Adaptadores virtuais
        verificacao.adapters_virtuais = DiagnosticoLinux.contar_adapters_virtuais()
        if verificacao.adapters_virtuais > 5:
            verificacao.avisos.append(f"{verificacao.adapters_virtuais} adaptadores virtuais detectados (Docker/VMs)")

        return verificacao
