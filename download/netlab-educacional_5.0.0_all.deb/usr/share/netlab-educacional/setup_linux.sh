#!/usr/bin/env bash
# ==============================================================================
# NetLab Educacional — Script de Instalação e Configuração para Linux
# ==============================================================================
# Suporta: Debian, Ubuntu, Kali Linux, Linux Mint, Fedora, Arch Linux, Manjaro
# ==============================================================================

set -e

VERMELHO='\033[0;31m'
VERDE='\033[0;32m'
AMARELO='\033[1;33m'
AZUL='\033[0;34m'
CIANO='\033[0;36m'
NEGRITO='\033[1m'
NC='\033[0m'

DIR_PROJETO="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR_PROJETO"

echo -e "${CIANO}${NEGRITO}================================================================${NC}"
echo -e "${CIANO}${NEGRITO}      NetLab Educacional — Assistente de Instalação Linux       ${NC}"
echo -e "${CIANO}${NEGRITO}================================================================${NC}"
echo ""

# ── 1. Detectar Gerenciador de Pacotes e Instalar Dependências de Sistema ──
echo -e "${AZUL}[1/4] Detectando sistema e instalando dependências nativas...${NC}"

if command -v apt &> /dev/null; then
    echo -e "Gerenciador detectado: ${VERDE}apt (Debian/Ubuntu/Kali/Mint)${NC}"
    echo "Instalando dependências de sistema (pode solicitar senha sudo)..."
    sudo apt update
    sudo apt install -y python3 python3-pip python3-venv libpcap-dev iproute2 traceroute wireless-tools net-tools libxcb-cursor0
elif command -v dnf &> /dev/null; then
    echo -e "Gerenciador detectado: ${VERDE}dnf (Fedora/RHEL)${NC}"
    echo "Instalando dependências de sistema (pode solicitar senha sudo)..."
    sudo dnf install -y python3 python3-pip libpcap-devel iproute traceroute net-tools
elif command -v pacman &> /dev/null; then
    echo -e "Gerenciador detectado: ${VERDE}pacman (Arch/Manjaro)${NC}"
    echo "Instalando dependências de sistema (pode solicitar senha sudo)..."
    sudo pacman -S --needed --noconfirm python python-pip libpcap iproute2 traceroute net-tools
else
    echo -e "${AMARELO}[AVISO] Gerenciador de pacotes não reconhecido automaticamente.${NC}"
    echo "Certifique-se de ter instalado: python3, python3-pip, libpcap e iproute2."
fi

# ── 2. Instalar Dependências Python ──
echo ""
echo -e "${AZUL}[2/4] Instalando dependências Python do requirements.txt...${NC}"

if [ -f "requirements.txt" ]; then
    pip3 install -r requirements.txt --break-system-packages 2>/dev/null || pip3 install -r requirements.txt
    echo -e "${VERDE}[OK] Pacotes Python instalados com sucesso!${NC}"
else
    echo -e "${VERMELHO}[ERRO] requirements.txt não encontrado!${NC}"
    exit 1
fi

# ── 3. Configurar Capabilities de Rede (Opcional sem sudo) ──
echo ""
echo -e "${AZUL}[3/4] Configuração de permissões de captura de pacotes...${NC}"
REAL_PYTHON=$(readlink -f $(which python3))

read -p "Deseja configurar permissões de rede no Python ($REAL_PYTHON) para rodar sem sudo? (S/n): " RESPOSTA_CAP
RESPOSTA_CAP=${RESPOSTA_CAP:-S}

if [[ "$RESPOSTA_CAP" =~ ^[Ss]$ ]]; then
    if sudo setcap cap_net_raw,cap_net_admin=eip "$REAL_PYTHON"; then
        echo -e "${VERDE}[OK] Permissões cap_net_raw configuradas no Python!${NC}"
    else
        echo -e "${AMARELO}[AVISO] Não foi possível aplicar setcap. O NetLab ainda funcionará com 'sudo ./run.sh'.${NC}"
    fi
fi

# ── 4. Criar Atalho no Desktop / Menu de Aplicativos ──
echo ""
echo -e "${AZUL}[4/4] Criando atalho no menu de aplicativos (.desktop)...${NC}"

CAMINHO_DESKTOP="$HOME/.local/share/applications/netlab.desktop"
mkdir -p "$HOME/.local/share/applications"

cat > "$CAMINHO_DESKTOP" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NetLab Educacional
Comment=Laboratório Educacional de Redes de Computadores e Cibersegurança
Exec=$DIR_PROJETO/run.sh
Icon=$DIR_PROJETO/icone.ico
Path=$DIR_PROJETO
Terminal=false
Categories=Education;Development;Network;
StartupNotify=true
EOF

chmod +x "$CAMINHO_DESKTOP"
echo -e "${VERDE}[OK] Atalho criado em: $CAMINHO_DESKTOP${NC}"

# Criar também no Desktop se a pasta existir
if [ -d "$HOME/Desktop" ] || [ -d "$HOME/Área de trabalho" ]; then
    DESKTOP_DIR="$HOME/Desktop"
    [ -d "$HOME/Área de trabalho" ] && DESKTOP_DIR="$HOME/Área de trabalho"
    cp "$CAMINHO_DESKTOP" "$DESKTOP_DIR/netlab.desktop"
    chmod +x "$DESKTOP_DIR/netlab.desktop"
    echo -e "${VERDE}[OK] Atalho copiado para a Área de Trabalho: $DESKTOP_DIR/netlab.desktop${NC}"
fi

echo ""
echo -e "${CIANO}${NEGRITO}================================================================${NC}"
echo -e "${VERDE}${NEGRITO}       Instalação Concluída com Sucesso!                        ${NC}"
echo -e "${CIANO}${NEGRITO}================================================================${NC}"
echo -e "Para iniciar o NetLab Educacional, execute:"
echo -e "   ${CIANO}./run.sh${NC}"
echo ""
