#!/usr/bin/env bash
# ==============================================================================
# NetLab Educacional — Script de Inicialização Linux
# ==============================================================================
# Este script verifica dependências, permissões de rede (raw sockets)
# e inicializa a aplicação com os parâmetros corretos.
# ==============================================================================

set -e

# Cores para mensagens no terminal
VERMELHO='\033[0;31m'
VERDE='\033[0;32m'
AMARELO='\033[1;33m'
AZUL='\033[0;34m'
CIANO='\033[0;36m'
NEGRITO='\033[1m'
NC='\033[0m' # No Color

DIR_PROJETO="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR_PROJETO"

echo -e "${CIANO}${NEGRITO}====================================================${NC}"
echo -e "${CIANO}${NEGRITO}       NetLab Educacional — Inicializador Linux     ${NC}"
echo -e "${CIANO}${NEGRITO}====================================================${NC}"

# ── 1. Verificar Python 3 ──
if ! command -v python3 &> /dev/null; then
    echo -e "${VERMELHO}[ERRO] Python 3 não foi encontrado no sistema!${NC}"
    echo -e "Instale com: sudo apt install python3 python3-pip (Debian/Ubuntu)"
    exit 1
fi

PYTHON_BIN="python3"

# Se existir venv local, use-o
if [ -f "$DIR_PROJETO/venv/bin/python" ]; then
    PYTHON_BIN="$DIR_PROJETO/venv/bin/python"
    echo -e "${AZUL}[INFO] Utilizando ambiente virtual: $DIR_PROJETO/venv${NC}"
fi

# ── 2. Checar parâmetros ──
if [[ "$1" == "--help" || "$1" == "-h" ]]; then
    echo -e "Uso: ./run.sh [OPÇÕES]"
    echo -e "Opções:"
    echo -e "  --check       Apenas verifica dependências e permissões"
    echo -e "  --setcap      Concede permissões raw socket ao Python sem precisar de sudo"
    echo -e "  --help, -h    Exibe esta mensagem de ajuda"
    exit 0
fi

if [[ "$1" == "--setcap" ]]; then
    REAL_PYTHON=$(readlink -f $(which $PYTHON_BIN))
    echo -e "${AMARELO}[INFO] Configurando capabilities de rede em: $REAL_PYTHON${NC}"
    sudo setcap cap_net_raw,cap_net_admin=eip "$REAL_PYTHON"
    echo -e "${VERDE}[OK] Capabilities configuradas com sucesso! Agora você pode rodar sem sudo.${NC}"
    exit 0
fi

# ── 3. Verificar libpcap ──
echo -e "${AZUL}[INFO] Verificando biblioteca libpcap...${NC}"
if ldconfig -p 2>/dev/null | grep -q "libpcap.so"; then
    echo -e "${VERDE}[OK] libpcap detectada no sistema.${NC}"
else
    echo -e "${AMARELO}[AVISO] libpcap.so pode não estar instalada.${NC}"
    echo -e "        Caso a captura falhe, instale: ${CIANO}sudo apt install libpcap-dev${NC}"
fi

# ── 4. Verificar Permissões (Root / Capabilities) ──
EUID_ATUAL=$(id -u)
TEM_CAP=0

if [ "$EUID_ATUAL" -eq 0 ]; then
    echo -e "${VERDE}[OK] Executando como superusuário (root). Permissões de captura ativas.${NC}"
else
    # Verificar se o executável do python tem cap_net_raw
    REAL_PYTHON=$(readlink -f $(which $PYTHON_BIN) 2>/dev/null || which $PYTHON_BIN)
    if command -v getcap &> /dev/null; then
        CAPS=$(getcap "$REAL_PYTHON" 2>/dev/null || true)
        if echo "$CAPS" | grep -q "cap_net_raw"; then
            TEM_CAP=1
            echo -e "${VERDE}[OK] Permissões cap_net_raw detectadas no Python ($REAL_PYTHON).${NC}"
        fi
    fi

    if [ "$TEM_CAP" -eq 0 ]; then
        echo -e "${AMARELO}[AVISO] O NetLab está sendo iniciado como usuário comum sem cap_net_raw.${NC}"
        echo -e "${AMARELO}        A captura de pacotes (Scapy AsyncSniffer) requer privilégios de rede.${NC}"
        echo -e "        Dicas:"
        echo -e "        - Para rodar com sudo: ${CIANO}sudo $PYTHON_BIN main.py${NC}"
        echo -e "        - Para liberar permissão permanente sem sudo: ${CIANO}./run.sh --setcap${NC}"
        echo ""
    fi
fi

if [[ "$1" == "--check" ]]; then
    echo -e "${VERDE}[OK] Verificação de ambiente concluída.${NC}"
    exit 0
fi

# ── 5. Executar Aplicação ──
echo -e "${CIANO}[INFO] Iniciando NetLab Educacional...${NC}"
exec "$PYTHON_BIN" main.py "$@"
