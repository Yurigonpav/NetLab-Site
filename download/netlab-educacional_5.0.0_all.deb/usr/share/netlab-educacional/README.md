<div align="center">

# NetLab Educacional — v5.0

**Plataforma desktop para ensino de redes de computadores, análise de tráfego em tempo real e segurança web em ambiente controlado.**

[![Download](https://img.shields.io/badge/Download-Instalador%20Windows-0078D4?style=for-the-badge&logo=windows&logoColor=white)](https://yurigonpav.github.io/NetLab-Site/#download)
[![Linux](https://img.shields.io/badge/Linux-Nativo%20%26%20Cross--Platform-FCC624?style=for-the-badge&logo=linux&logoColor=black)](run.sh)
[![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)
[![PyQt6](https://img.shields.io/badge/PyQt6-Interface%20Qt-41CD52?style=for-the-badge&logo=qt&logoColor=white)](https://pypi.org/project/PyQt6/)
[![Scapy](https://img.shields.io/badge/Scapy-Captura%20de%20Pacotes-FF6B35?style=for-the-badge)](https://scapy.net/)

**Trabalho de Conclusão de Curso — Curso Técnico em Informática**
**Instituto Federal Farroupilha, Campus Uruguaiana**

</div>

---

> [!TIP]
> **Compatibilidade Multiplataforma:** O NetLab Educacional agora possui suporte nativo completo para **Linux** (Debian, Ubuntu, Kali Linux, Fedora, Arch Linux, etc.) e **Windows 10/11**, com detecção automática de sistema, drivers de captura e permissões de rede.

---

## Sumário

- [Sobre o Projeto](#sobre-o-projeto)
- [Funcionalidades](#funcionalidades)
- [Arquitetura e Estrutura](#arquitetura-e-estrutura-do-projeto)
- [Requisitos do Sistema](#requisitos-do-sistema)
- [Guia de Instalação e Execução (Linux)](#guia-de-instalação-e-execução-linux)
- [Guia do Desenvolvedor (Windows)](#guia-do-desenvolvedor-windows)
- [Fluxo de Uso Recomendado](#fluxo-de-uso-recomendado)
- [Protocolos Analisados](#protocolos-analisados)
- [Servidor de Laboratório](#servidor-de-laboratório)
- [Diagnóstico do Sistema](#diagnóstico-do-sistema)
- [Persistência e Dados Gerados](#persistência-e-dados-gerados)
- [Limitações Conhecidas](#limitações-conhecidas)
- [Escopo Ético e Segurança](#escopo-ético-e-segurança)
- [Autor](#autor)

---

## Sobre o Projeto

O **NetLab Educacional** é uma aplicação desktop desenvolvida em Python para apoiar aulas práticas de redes de computadores e segurança da informação no ensino técnico. O sistema captura pacotes de rede em tempo real, organiza o tráfego em eventos compreensíveis, exibe uma topologia interativa da rede local e gera automaticamente explicações pedagógicas sobre protocolos, riscos e evidências técnicas.

A proposta central é aproximar conceitos normalmente abstratos — como handshake TCP, envenenamento ARP, credenciais em texto claro, SQL Injection e XSS — de uma experiência **diretamente observável** em sala de aula. O projeto combina captura real de pacotes com um servidor HTTP intencionalmente vulnerável, permitindo demonstrar o ciclo completo:

```
ação do usuário → tráfego de rede → captura → interpretação técnica → explicação didática
```

> O software foi construído para uso local, em laboratório ou sala de aula. O servidor vulnerável incluído é intencionalmente inseguro e deve ser usado **exclusivamente** em redes controladas.

---

## Requisitos do Sistema

### Sistemas Operacionais Suportados

- **Linux:** Ubuntu 22.04+, Debian 12+, Kali Linux, Linux Mint, Fedora 38+, Arch Linux, Manjaro.
- **Windows:** Windows 10 ou Windows 11 (64-bit).

### Drivers e Dependências Nativas

| Sistema | Driver / Pacote de Captura | Como instalar |
|---|---|---|
| **Linux (Debian/Ubuntu/Kali)** | `libpcap-dev`, `iproute2`, `traceroute` | `sudo apt install libpcap-dev iproute2 traceroute wireless-tools` |
| **Linux (Fedora/RHEL)** | `libpcap-devel`, `iproute`, `traceroute` | `sudo dnf install libpcap-devel iproute traceroute` |
| **Linux (Arch/Manjaro)** | `libpcap`, `iproute2`, `traceroute` | `sudo pacman -S libpcap iproute2 traceroute` |
| **Windows** | `Npcap 1.70+` | [Baixar no site oficial do Npcap](https://npcap.com/) (modo WinPcap API-compatible) |

### Dependências Python

```
PyQt6
scapy
pyqtgraph
cryptography
manuf
psutil
qrcode
```

---

## Guia de Instalação e Execução (Linux)

### 🚀 Instalação Rápida (1 Comando)

O projeto inclui um assistente automatizado de configuração para Linux:

```bash
chmod +x setup_linux.sh
./setup_linux.sh
```

O script irá:
1. Detectar sua distribuição e instalar dependências de sistema (`libpcap`, `traceroute`, etc.).
2. Instalar as dependências do `requirements.txt`.
3. Configurar capabilities de rede (`setcap`) para que você possa capturar pacotes sem precisar de `sudo`.
4. Criar atalhos na Área de Trabalho e no menu de aplicativos do sistema (`netlab.desktop`).

---

### ▶️ Executando no Linux

Você pode iniciar o NetLab usando o inicializador inteligente:

```bash
# Execução direta
./run.sh

# Ou verificar permissões e dependências antes de iniciar
./run.sh --check

# Ou executar como superusuário (caso não queira usar capabilities)
sudo python3 main.py
```

> [!TIP]
> **Captura sem sudo no Linux:** Se preferir rodar sem digitar senha toda vez, configure permissões no executável Python:
> ```bash
> sudo setcap cap_net_raw,cap_net_admin=eip $(readlink -f $(which python3))
> ```

---

## Instalação no Windows (Usuários Finais)

Para utilizar o NetLab no Windows, não é necessário configurar ambiente de desenvolvimento:
1. Acesse a página oficial de download: **[https://yurigonpav.github.io/NetLab-Site/](https://yurigonpav.github.io/NetLab-Site/)**
2. Baixe o instalador oficial (`.exe`).
3. Execute o instalador para configurar automaticamente os atalhos e componentes de sistema.

---

## Guia do Desenvolvedor (Windows)

Para rodar ou modificar o código-fonte no Windows, siga os passos abaixo:

### 1. Configuração do Ambiente

Abra o PowerShell **como Administrador** e execute:

```powershell
# Clonar o repositório
git clone https://github.com/Yurigonpav/NetLab-Educacional.git
cd NetLab-Educacional

# Criar e ativar ambiente virtual
python -m venv venv
.\venv\Scripts\Activate.ps1

# Instalar dependências
python -m pip install --upgrade pip
pip install -r requirements.txt
```

> [!NOTE]
> Se a política de execução do PowerShell bloquear a ativação: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

### 2. Execução no Windows

```powershell
# Com o venv ativo e como Administrador
python main.py
```

### 3. Geração do Executável (.exe)

O NetLab pode ser empacotado em um único executável para Windows usando o **PyInstaller**:

```powershell
pip install pyinstaller
pyinstaller NetLab.spec
```

O arquivo final será gerado em `dist\NetLab Educacional.exe`.

### 4. Diagnóstico Standalone

Para testar as interfaces de rede rapidamente via terminal:

```bash
python3 diagnostico.py   # Linux
python diagnostico.py    # Windows
```

---

## Fluxo de Uso Recomendado

```
1. Abrir PowerShell como Administrador
2. Ativar venv e executar python main.py
3. Selecionar a interface de rede correta no combo
4. Clicar em "Iniciar Captura"
5. Abrir o navegador e acessar qualquer site
6. Observar dispositivos aparecendo na aba Topologia
7. Observar eventos na aba Modo Análise
8. (Opcional) Abrir a aba Servidor → Iniciar Servidor → acessar pelo navegador
9. Executar ataques didáticos → observar o NetLab detectar e explicar cada um
```

### Demonstração completa com a turma (Wi-Fi)

Ative o **Hotspot Móvel** do Windows no computador com o NetLab (Configurações → Rede → Hotspot Móvel). Conecte os dispositivos dos alunos nesse hotspot. O adaptador em modo AP captura todo o tráfego que passa por ele, tornando visível o tráfego de todos os dispositivos conectados.

```
Alunos conectam ao hotspot
    │
    ▼
NetLab captura o tráfego de todos
    │
    ▼
Topologia exibe os dispositivos da turma
    │
    ▼
Modo Análise explica cada protocolo em tempo real
```

### Ciclo didático completo com o servidor vulnerável

```
Iniciar captura → Iniciar servidor → Executar ataque no navegador
    → NetLab captura o tráfego HTTP
    → Motor pedagógico gera explicação
    → Painel de Alertas do Servidor registra o ataque
    → Discussão com a turma
```

---

## Protocolos Analisados

| Protocolo | Tratamento | Evidências extraídas |
|---|---|---|
| **HTTP** | DPI completa | Método, host, caminho, headers, cookies, corpo, formulários, campos sensíveis, SQL Injection, XSS |
| **HTTPS** | Classificação + explicação TLS | IPs, porta, SNI (Server Name Indication) do ClientHello |
| **DNS** | Identificação de consulta | Domínio consultado, servidor DNS, tamanho |
| **ARP** | Descoberta local | MAC de origem, operação (request/reply), fabricante OUI |
| **ICMP** | Diagnóstico | Origem, destino, TTL, estimativa de SO, saltos percorridos |
| **DHCP** | Configuração dinâmica | Tipo DHCP (discover/offer/request/ack/nak), XID |
| **TCP SYN** | Nova conexão | IPs, portas, início de handshake, TTL, estimativa de SO |
| **TCP FIN** | Encerramento ordenado | Contexto de finalização da sessão |
| **TCP RST** | Reset abrupto | Porta recusada ou firewall |
| **SSH** | Acesso remoto cifrado | IPs, portas, risco operacional |
| **FTP** | Transferência insegura | Exposição de credenciais e arquivos |
| **SMB** | Compartilhamento de arquivos | Versão, risco de relay NTLM |
| **RDP** | Desktop remoto | Exposição de serviço remoto, risco de brute force |

---

## Servidor de Laboratório

O NetLab inclui um servidor HTTP educacional em `painel_servidor.py`, projetado para demonstrar vulnerabilidades web reais em ambiente controlado.

### Características técnicas

- Servidor HTTP multithread (`ThreadingMixIn + HTTPServer`).
- Banco de dados **SQLite exclusivamente em memória** — todos os dados são destruídos ao parar o servidor.
- Nenhum acesso ao sistema operacional (sem `subprocess`, `os.system`, `eval` ou `exec`).
- Nenhuma persistência em disco de dados de usuários ou sessões.

### Iniciando o servidor

1. Acesse a aba **Servidor**.
2. Ajuste a porta (padrão: `8080`) com os botões +/−.
3. Clique em **Iniciar Servidor**.
4. Acesse o endereço exibido de qualquer dispositivo na mesma rede:

```
http://<ip-do-computador>:8080/
```

### Credenciais padrão

| Usuário | Senha | Papel |
|---|---|---|
| `admin` | `123456` | admin |
| `alice` | `alice123` | user |
| `bob` | `bob456` | user |
| `carlos` | `senha123` | user |

### Rotas disponíveis

| Rota | Método | Vulnerabilidade demonstrada |
|---|---|---|
| `/` | GET | Página inicial — estado da sessão ativa |
| `/login` | GET / POST | SQL Injection (concatenação direta) + força bruta sem limite de tentativas |
| `/register` | GET / POST | SQL Injection no INSERT + tokens de sessão previsíveis (sequenciais) |
| `/logout` | GET | Encerramento de sessão |
| `/produtos` | GET | SQL Injection no parâmetro `id` (UNION SELECT funcional) |
| `/busca` | GET | XSS Refletido no parâmetro `q` (sem escape HTML) |
| `/comentarios` | GET / POST | XSS Armazenado + CSRF (sem token de proteção) |
| `/pedidos` | GET | IDOR — acessa pedido de qualquer usuário por troca do parâmetro `id` |
| `/usuarios` | GET | Exposição de todos os usuários e senhas em texto puro sem autenticação |
| `/perfil` | GET | XSS Refletido no parâmetro `nome` |
| `/api/dados` | GET | API pública sem autenticação |
| `/api/usuarios` | GET | JSON com todos os usuários e senhas sem autenticação |

### Vulnerabilidades implementadas

| Classe | Onde aparece | Objetivo pedagógico |
|---|---|---|
| **SQL Injection** | `/login`, `/produtos`, `/register`, `/comentarios` | Risco de concatenação direta de strings em queries SQL |
| **XSS Refletido** | `/busca`, `/perfil` | Injeção de HTML/JavaScript refletido imediatamente na resposta |
| **XSS Armazenado** | `/comentarios` | Payload persistido no banco e executado em todo acesso à página |
| **IDOR** | `/pedidos?id=` | Acesso indevido a recursos de outros usuários por troca de identificador |
| **CSRF** | Todos os formulários | Ausência de token de validação de origem da requisição |
| **Força Bruta** | `/login` | Ausência de rate limiting ou bloqueio de conta |
| **Sessão Previsível** | Tokens sequenciais | Tokens de sessão adivinháveis (`token1`, `token2`...) |
| **Divulgação de Dados** | `/usuarios`, `/api/usuarios` | Exposição de credenciais sem qualquer controle de acesso |

### Heurísticas de usabilidade nos formulários

Os formulários do servidor incluem melhorias de UX para demonstração mais realista:

- Botão **Mostrar/Ocultar** senha com `aria-pressed` e foco automático.
- Campos `<label>` associados a cada `<input>`.
- Validação em tempo real no cadastro (senha apenas números, confirmação de senha).
- `aria-live` para feedback acessível a leitores de tela.
- Foco visível por teclado (`focus-visible`).
- Link "pular ao conteúdo principal" para acessibilidade.
- Prevenção de envio duplicado por mudança de estado e `aria-busy` no botão.

### Painel de controle do servidor

A aba Servidor exibe em tempo real:

- **Tabela de requisições**: hora, IP do cliente, método, endpoint, tamanho, tempo de resposta.
- **Log de alertas**: cada ataque detectado (SQLi, XSS, IDOR, CSRF) com timestamp e payload.
- **Métricas**: total de requisições, dados transmitidos, clientes únicos e barra de carga.

---

## Diagnóstico do Sistema

Acesse via botão **Diagnóstico** na barra de ferramentas.

### Verificações realizadas

| Seção | O que verifica |
|---|---|
| **Checklist Rápido** | Admin, Npcap, Scapy, DNS, gateway em uma visão consolidada |
| **Interface e Estatísticas** | Interface selecionada, IP local, pacotes, drops e erros via `psutil` |
| **Sinal Wi-Fi** | SSID, BSSID, sinal em %, canal, velocidade de recepção |
| **Versões dos Componentes** | Python, Npcap, Scapy, PyQt6 e versão do Windows |
| **Conectividade de Rede** | Ping real ao gateway (latência e % perda) + DNS com tempo de resposta |
| **Pendências Detectadas** | Lista automática de problemas e avisos encontrados |

### Pontuação de saúde

| Pontuação | Status |
|---|---|
| 8–10 | Sistema saudável |
| 5–7 | Atenção necessária |
| 0–4 | Problemas encontrados |

### Script standalone

Para diagnóstico sem abrir a interface principal:

```powershell
python diagnostico.py
```

Testa cada interface por **4 segundos** e mostra quantos pacotes foram capturados em cada uma. Útil para identificar a interface correta em um ambiente desconhecido.

---

## Persistência e Dados Gerados

O NetLab minimiza intencionalmente a persistência de dados capturados. A maioria das informações existe apenas em memória durante a sessão.

| Dado | Local | Finalidade |
|---|---|---|
| Apelidos de dispositivos | `dados/aliases.json` | Manter nomes personalizados de hosts entre sessões |
| Relatórios de Diagnóstico | `diagnóstico/*.txt` | Exportações manuais de saúde do sistema |
| Cache OUI do Wireshark | `~/.cache/manuf/manuf` | Acelerar a identificação de fabricantes por MAC |

**Dados que existem apenas em memória (perdidos ao fechar):**

- Pacotes e eventos capturados.
- Métricas agregadas por protocolo e dispositivo.
- Sessões de usuário do servidor de laboratório.
- Usuários, produtos, pedidos e comentários do servidor de laboratório.
- Banco de dados SQLite do servidor (destruído ao parar o servidor).

---

## Limitações Conhecidas

- Esta versão conta com **suporte nativo e documentado para distribuições Linux** (Ubuntu, Debian, Kali, Fedora, Arch), além de manter retrocompatibilidade com Windows.
- Captura de tráfego de **terceiros em Wi-Fi** é limitada pelos drivers do sistema operacional no Windows. No Linux, requer modo monitor caso suportado pelo hardware.
- Conteúdo de **HTTPS não é decriptado**; apenas metadados observáveis (IPs, porta, SNI) são analisados.
- O analisador prioriza **IPv4**.
- A topologia visual suporta até **50 dispositivos simultâneos** para preservar o desempenho.
- A identificação de fabricante depende da qualidade e atualização da base OUI local.
- Em redes com volume muito alto, eventos podem ser agregados ou limitados pela fila interna.

---

## Escopo Ético e Segurança

O NetLab Educacional foi desenvolvido para **ensino, demonstração e pesquisa em ambientes autorizados**.

**Uso permitido:**

- Laboratórios e salas de aula.
- Redes próprias e de teste.
- Demonstrações com consentimento dos participantes.
- Estudos de protocolos e segurança defensiva.

**Uso não permitido:**

- Capturar tráfego de terceiros sem autorização.
- Expor o servidor vulnerável na internet.
- Aplicar as técnicas demonstradas contra sistemas reais sem permissão explícita.
- Coletar, armazenar ou divulgar credenciais reais de terceiros.

> O servidor vulnerável implementa falhas reais com finalidade didática. Mantenha-o sempre restrito à rede local de teste.

---



---

## Verificação de Integridade

Para verificar se o projeto está em estado executável sem abrir a interface:

```powershell
# Compilar todos os módulos (detecta erros de sintaxe)
.\venv\Scripts\python.exe -m compileall -q . -x "venv|__pycache__|\.git"

# Testar interfaces disponíveis
.\venv\Scripts\python.exe diagnostico.py

# Iniciar a aplicação
.\venv\Scripts\python.exe main.py
```

---

## Autor

**Yuri Gonçalves Pavão**

Curso Técnico em Informática Integrado ao Ensino Médio
Instituto Federal Farroupilha — Campus Uruguaiana

Orientador: Prof. João Carlos
Co-orientador: Prof. Michel Michelon

- GitHub: [@Yurigonpav](https://github.com/Yurigonpav)
- Instagram: [@yuri_g0n](https://instagram.com/yuri_g0n)

---

<div align="center">

**Desenvolvido com finalidade educacional. Use exclusivamente em ambientes autorizados.**

</div>
